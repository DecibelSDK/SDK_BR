//
//  SDK_BR.h
//  SDK_BR
//
//  Created by victor iglesias on 3/5/24.
//

#import <Foundation/Foundation.h>

//! Project version number for SDK_BR.
FOUNDATION_EXPORT double SDK_BRVersionNumber;

//! Project version string for SDK_BR.
FOUNDATION_EXPORT const unsigned char SDK_BRVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SDK_BR/PublicHeader.h>


